from sodapy.socrata import Socrata

__all__ = ['Socrata', ]
